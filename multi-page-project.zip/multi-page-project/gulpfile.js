'use strict';

const path = {
	build: {
		html: 'build/',
		js: 'build/js/',
		css: 'build/css/',
		images: 'build/assets/images/',
		fonts: 'build/assets/fonts/',
		libraries: 'build/libraries/'
	},
	src: {
		html: 'src/*.html',
		js: 'src/js/**/*.js',
		styles: 'src/styles/main.sass',
		images: 'src/assets/images/**/*.*',
		fonts: 'src/assets/fonts/**/*.*',
		libraries: 'src/libraries/**/*.*'
	},
	watch: {
		html: 'src/**/*.html',
		js: 'src/js/**/*.js',
		css: 'src/styles/**/*.sass',
		images: 'src/assets/images/**/*.*',
		fonts: 'src/assets/fonts/**/*.*',
		css_build: 'build/css/*.css',
		js_build: 'build/js/*.js'
	},
	clean: './build/*'
};

const config = {
	server: {
		baseDir: './build'
	}
};

const gulp = require('gulp');
const webserver = require('browser-sync');
const plumber = require('gulp-plumber');
const rigger = require('gulp-rigger');
const sass = require('gulp-sass');
const autoprefixer = require('gulp-autoprefixer');
const cleanCSS = require('gulp-clean-css');
const uglify = require('gulp-uglify-es').default;
const cache = require('gulp-cache');
const rimraf = require('gulp-rimraf');
const rename = require('gulp-rename');

gulp.task('webserver', function () {
	webserver(config);
});

gulp.task('html:build', function () {
	return gulp.src(path.src.html)
		.pipe(plumber())
		.pipe(rigger())
		.pipe(gulp.dest(path.build.html))
		.pipe(webserver.reload({ stream: true }));
});

gulp.task('css:build', function () {
	return gulp
		.src(path.src.styles)
		.pipe(plumber())
		.pipe(
			sass({
				outputStyle: 'expanded'
			}).on('error', sass.logError))
		.pipe(
			autoprefixer({
				cascade: false,
				overrideBrowserslist: ['last 4 versions']
			})
		)
		.pipe(gulp.dest(path.build.css))
		.pipe(rename({ suffix: '.min' }))
		.pipe(cleanCSS())
		.pipe(gulp.dest(path.build.css))
		.pipe(webserver.reload({ stream: true }));
});

gulp.task('js:build', function () {
	return gulp.src(path.src.js)
		.pipe(plumber())
		.pipe(rigger())
		.pipe(gulp.dest(path.build.js))
		.pipe(rename({ suffix: '.min' }))
		.pipe(uglify())
		.pipe(gulp.dest(path.build.js))
		.pipe(webserver.reload({ stream: true }));
});

gulp.task('fonts:build', function () {
	return gulp.src(path.src.fonts).pipe(gulp.dest(path.build.fonts));
});

gulp.task('images:build', function () {
	return gulp.src(path.src.images).pipe(gulp.dest(path.build.images));
});

gulp.task('libraries:build', function () {
	return gulp.src(path.src.libraries).pipe(gulp.dest(path.build.libraries));
});

gulp.task('clean:build', function () {
	return gulp.src(path.clean, { read: false }).pipe(rimraf());
});

gulp.task('cache:clear', function () {
	cache.clearAll();
});

gulp.task('build',
	gulp.series(
		'clean:build',
		gulp.parallel(
			'html:build',
			'css:build',
			'js:build',
			'fonts:build',
			'images:build',
			'libraries:build'
		)
	)
);

gulp.task('watch', function () {
	gulp.watch(path.watch.html, gulp.series('html:build'));
	gulp.watch(path.watch.css, gulp.series('css:build'));
	gulp.watch(path.watch.js, gulp.series('js:build'));
	gulp.watch(path.watch.images, gulp.series('images:build'));
	gulp.watch(path.watch.fonts, gulp.series('fonts:build'));
	gulp.watch(path.watch.fonts, gulp.series('libraries:build'));
	gulp.watch(path.watch.css_build).on('change', webserver.reload);
	gulp.watch(path.watch.js_build).on('change', webserver.reload);
});

gulp.task('default', gulp.series('build', gulp.parallel('webserver', 'watch')));
