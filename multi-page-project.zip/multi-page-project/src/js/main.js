(function () {
	console.log('I am working!');
}());
